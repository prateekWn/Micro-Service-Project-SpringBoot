package com.contact.contact_services;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ContactServicesApplicationTests {

	@Test
	void contextLoads() {
	}

}
